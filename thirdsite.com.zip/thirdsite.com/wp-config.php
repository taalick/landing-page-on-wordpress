<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'thirdsite');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '3B`#2nq!H sUZVCU/Hx,kjzP5KG_g+~dz]3s5${d#eGpsR+0/LHJJFUf.WsD%K[s');
define('SECURE_AUTH_KEY',  'zt[$g<JKTddP0Nh`dZqZ10&sR/Z~>]n0&faMW:#CD.5M %( 2Hj5R :1#]SFsy|`');
define('LOGGED_IN_KEY',    '@LCKE4yLnb_Hp*M@q[[uD(/m2WyRFkKtuvo9&[EfpI&eCkvh|Qf8*o|[2{FQV[TZ');
define('NONCE_KEY',        ';K8vrKzJA9:cLe;7oN#9GV5%-[qv9nR6x&|q<Fg}VYoGd&acEUD7X5pkL^|?uw`G');
define('AUTH_SALT',        '5~Q*RCb+L*v~nTlIJxQ;?p{@}Pm]12v=rm+gN*<[EWFh@G+;>6(9VPgmf7^Rww%K');
define('SECURE_AUTH_SALT', '4p!|%1#jk>4]*QC:w1YD.u}Cz&L`j5rM*E6~;z4]9tu$rgqHNiEaUpx;)u$HR_F@');
define('LOGGED_IN_SALT',   ',<U}Z**WC0n@N|q;.R>Jy9FND7dwn2HFnm$8cea(O0RB9x$QW-;`V:-FZ36(n/-g');
define('NONCE_SALT',       'wg%YutQ&k[8?V4leLMSY98P9T5m&+.K3%4Q2/U6!Y%E7D}W/xK4Z_TL^;DCM&1!j');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
